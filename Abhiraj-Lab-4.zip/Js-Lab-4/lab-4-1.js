﻿//#### LAB 4 - FUNCTIONS ####
//PART 1:  PROGRAM ALERT FUNCTION
//################## CREATE YOUR FUNCTION

function popup(courseCode,courseName){
   alert("the course code is" + " " + " "+ courseCode + "" + "Course name is" + courseName );
}
//################## TEST YOUR FUNCTION
popup("HTTP5121","Webdesign");

popup("IXD5106","(Interaction Design");
popup("HTTP5122","Front-End Web Development");