﻿//#### LAB 4 - FUNCTIONS ####
//PART 2:  AN AVERAGE FUNCTION
function Average(a,b,c,d,e){
    var avg = (a+b+c+d+e)/5;
    return avg
}

//################## CREATE YOUR AVERAGE FUNCTION
//This function takes five numbers and returns their average to one decimal place.


console.log(Average(5,10,15,20,25));
//################## LOGIC THAT OUTPUTS MESSAGES BASED ON FUNCTION RESULTS

var HTTP5125 = 70;
var HTTP5126 = 85;
var HTTP5114 = 85;
var HTTP5121 = 70;
var IXD5106 = 60;


if(Average(HTTP5125,HTTP5126,HTTP5114,HTTP5121,IXD5106,)>=70){
alert("success");
}
else{
alert("Review record")
}